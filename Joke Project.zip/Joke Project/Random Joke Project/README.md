# js-jokes-setup
JOKES API PROJECT SETUP
